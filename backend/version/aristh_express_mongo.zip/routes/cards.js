const express = require('express');
const cardsApi = express.Router();

const {
  getCards,
  createCard,
  deleteCard,
  likeCard,
  dislikeCard,
}= require('../controllers/cards');

cardsApi.get('/', getCards);
cardsApi.post('/', createCard);
cardsApi.delete('/:cardId', deleteCard);
cardsApi.put('/:cardId/likes', likeCard);
cardsApi.delete('/:cardId/likes', dislikeCard);

module.exports = cardsApi;
