const express = require('express');
const bodyParser = require('body-parser');
const userApi = express.Router();

const {
  getUsers,
  getUserById,
  createUser,
  addProfile,
  addAvatar
} = require('../controllers/users');

userApi.use(bodyParser.json());
userApi.use(bodyParser.urlencoded({ extended: true }));

userApi.get('/', getUsers);
userApi.get('/:id', getUserById);
userApi.post('/', createUser);
userApi.patch('/:id/profile', addProfile);
userApi.patch('/:id/avatar', addAvatar);

module.exports = userApi;
