const mongoose = require('mongoose');
const express = require('express');
const { port = 3000 } = process.env;

const app = express();

const usersAPI = require('./routes/users');
const cardsAPI = require('./routes/cards');

mongoose.connect('mongodb://127.0.0.1:27017/aroundb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Failed to connect to MongoDB", err))


// Middlewares

app.use('/users', usersAPI);
app.use('/cards', cardsAPI);

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
