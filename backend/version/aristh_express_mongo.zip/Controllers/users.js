const userModelMongo = require('../models/users');

const getUsers = (req, res) => {
  userModelMongo.find({})
    .then(users => {
      res.json({data: users});
    })
    .catch(err => {
      res.status(404).json({message: 'No se encuentra la página', error: err});
    });
};


const getUserById = (req, res) => {
  userModelMongo.findById(req.params.id).
    orFail(() => {
      const err = new Error('No se encuentra el usuario');
      err.status = 404;
      throw err;
    })
};

const createUser = (req, res) => {

  if (!req.body) {
    res.status(404).json({message: 'Faltan datos para crear el usuario'});
    return;
  }

  const {name, about, avatar} = req.body;
  const user = new userModelMongo({name, about, avatar});

  user.save()
    .then((user) => res.send({ data: user }))
    .catch((err) => res.status(400).send({ message: 'Hubo un error al guardar el usuario', error: err }));
};

const addProfile = (req, res) => {
  userModelMongo.findByIdAndUpdate(req.params.id, {profile: req.body.profile}, {new: true})
    .orFail(() => {
      const err = new Error('No se encuentra el usuario');
      err.status = 404;
      throw err;
    })
    .then((user) => res.send({ data: updateUser }))
    .catch((err) => res.status(400).send({ message: 'Hubo un error al guardar el usuario', error: err }));
}

const addAvatar = (req, res) => {
  userModelMongo.findByIdAndUpdate(req.params.id, {avatar: req.body.avatar}, {new: true})
    .orFail(() => {
      const err = new Error('No se encuentra el usuario');
      err.status = 404;
      throw err;
    })
    .then((user) => res.send({ data: updateUser }))
    .catch((err) => res.status(400).send({ message: 'Hubo un error al guardar el usuario', error: err }));
}

module.exports = {
  getUsers,
  getUserById,
  createUser,
  addProfile,
  addAvatar
}
